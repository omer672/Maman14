#include "symbolTable.h"
#include "Parsing.h"
/*The function creates all requested files to create
 * Input: file name
 * Output: .ob , .ext, .ent files*/
void createOutputFiles(char* fileName);
