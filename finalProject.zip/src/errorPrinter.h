#include "main.h"

/*The function will print the error with the line the error appeared in, and the file name in which the error appeared in */
void printError(StatusCode code, int line, char* fileName);
